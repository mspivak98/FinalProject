
function signin() {
    var mailformat = /^\w+((.\w+)|(-\w+))@[A-Za-z0-9]+((.|-)[A-Za-z0-9]+).[A-Za-z0-9]+$/;  
    var logerr3 = document.getElementById("LogEerr");
    var E_mail= document.getElementById("logEmail");
  
    var logerrortoThrow3="";
  
    var logpass  = document.getElementById("logpassword").value;
   
    var logerr4  = document.getElementById("LogPerr");
    var logerrortoThrow4="";
  
  
  
    try {
      if(E_mail.value == "")  {   
        logerrortoThrow3 += "Your E-mail field is empty";
      }
  
      if((mailformat.test(E_mail.value)==false)&&(E_mail.value!=="")){
        logerrortoThrow3 += "Please enter a valid E-mail address.";
      }
    
      throw logerrortoThrow3;
    } 
  
   
    catch(logerrors3) {
      logerr3.innerHTML=logerrors3; 
    }
  
    try {
      if(logpass == "")  {  
        logerrortoThrow4 += "Your password field is empty";
      }
  
    throw logerrortoThrow4;
    }
   
   
    catch(logerrors4) {
      logerr4.innerHTML=logerrors4; 
    }
  }