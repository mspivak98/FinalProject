from flask import Flask, render_template, request

app= Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")
    # def register():
    # return render_template("register.html")
    # def signin():
    # return render_template("signin.html")



@app.route("/register", methods=['POST'])
def register():
    if request.method=='POST':
        firstName=request.form["re_first_name"]
        lastName=request.form["re_last_name"]
        email=request.form["re_email_name"]
        password=request.form["re_password_name"]
        passwordConfirm=request.form["re_confirm_password_name"]
        return render_template("register.html")





if __name__=='__main__':
    app.debug=True
    app.run()