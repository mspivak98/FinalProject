from flask import Flask, render_template, request
from flask_sqlalchemy import SQLAlchemy

app= Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:12345@localhost:5434/Final'
db=SQLAlchemy(app)

# 

class Data(db.Model):
    __tablename__="data"
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(30))
    last_name = db.Column(db.String(30))
    email = db.Column(db.String(120), unique=True)
    password = db.Column(db.String(20))

    def __init__(self, first_name_, last_name_, email_, password_):
        self.first_name = first_name_
        self.last_name = last_name_
        self.email = email_
        self.password = password_


# 
@app.route("/")
def index():
    return render_template("index.html")

# 
@app.route('/signin', methods=['GET', 'POST'])
def signin():
    if request.method=='POST':
        email=request.form["email_name"]
        password=request.form["password_name"]
    return render_template("signin.html")

# @Route GET/POST 
# @desc register
# @access Public
@app.route("/register", methods=['GET','POST'])
def register():
    if request.method=='POST':
        firstName = request.form["re_first_name"]
        lastName = request.form["re_last_name"]
        email = request.form["re_email_name"]
        password = request.form["re_password_name"]

        # store form data into database
        data = Data(firstName, lastName, email, password)
        db.session.add(data)
        db.session.commit()
        # go to the sign page
        return render_template("signin.html")

    return render_template("register.html")
    


if __name__=='__main__':
    app.debug=True
    app.run()