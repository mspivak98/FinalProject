function checkpassword() {
//   var err1= document.getElementById("Ferr");
//   var Fname = document.getElementById("Firstname").value;
//   var errortoThrow1="";

//   var err2= document.getElementById("Lerr"); 
//   var Lname = document.getElementById("Lastname").value;
//   var errortoThrow2="";


//   var mailformat = /^\w+((.\w+)|(-\w+))@[A-Za-z0-9]+((.|-)[A-Za-z0-9]+).[A-Za-z0-9]+$/;  
//   var err3 = document.getElementById("Eerr");
//   var E_mail= document.getElementById("Email");
  
//   var errortoThrow3="";

//   var pass  = document.getElementById("Password").value;
//   var pass2 = document.getElementById("Password2").value;
//   var err4  = document.getElementById("Perr");
//   var errortoThrow4="";


// try { 
//   if(Fname == "")  {   
//     errortoThrow1 += "Your First name field is empty";
//     }
//   throw errortoThrow1;
// }



// catch(errors1) {
//   err1.innerHTML=errors1; 
//   }

// try {
//   if(Lname == "")  {   
//     errortoThrow2 += "Your Last name field is empty";
//     }
//   throw errortoThrow2;
//  }



//  catch(errors2) {
//    err2.innerHTML=errors2;
//   }

//  try {
//     if(E_mail.value == "")  {   
//       errortoThrow3 += "Your E-mail field is empty";
//     }
//     if((mailformat.test(E_mail.value)==false)&&(E_mail.value!=="")){
//       errortoThrow3 += "Please enter a valid E-mail address.";
//     }
//     throw errortoThrow3;
//   }



//  catch(errors3) {
//     err3.innerHTML=errors3;
//   }

//   try {
//     if(pass == "")  {  
//       errortoThrow4 += "Your password field is empty";
//     }

//     if((pass.length<6)&&(pass!== "")) { 
//       errortoThrow4 += "Your password is is too short.";
//     } 

//     if((/[A-Z]/g.test(pass) == false)&&(pass!== "")){
//       errortoThrow4 +=   "Your password  should have atleast one capital letter."; 
//     }

//     if((pass != pass2)&&(pass!== "")){ 
//       errortoThrow4 +=   "Your password  does not match.";
//     }

//     if((/\d/g.test(pass) == false)&&(pass!== "")){  
// 	    errortoThrow4 += "Your password should have atleast one digit.";
//     }

//     throw errortoThrow4;
//   }
 
 
//   catch(errors4) {
//     err4.innerHTML=errors4;
//   }
  if (document.getElementById('Password').value == "" ||  document.getElementById('Password2').value == "") {
    document.getElementById('message').innerHTML = '';
  }
  else if (document.getElementById('Password').value == document.getElementById('Password2').value) {
    document.getElementById('message').style.color = 'green';
    document.getElementById('message').innerHTML = 'Password matching';
    document.getElementById("submitbutton").disabled = false;

  } else {
    document.getElementById('message').style.color = 'red';
    document.getElementById('message').innerHTML = 'Password not matching';
    document.getElementById("submitbutton").disabled = true;
  }

}