from flask import Flask, render_template, request

app= Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route('/signin', methods=['GET', 'POST'])
def signin():
    if request.method=='POST':
        email=request.form["email_name"]
        password=request.form["password_name"]
    return render_template("signin.html")


@app.route("/register", methods=['GET','POST'])
def register():
    if request.method=='POST':
        firstName = request.form["re_first_name"]
        lastName = request.form["re_last_name"]
        email = request.form["re_email_name"]
        password = request.form["re_password_name"]
        passwordConfirm = request.form["re_confirm_password_name"]
        print('first', firstName)
        print('last', lastName)
        print('email', email)
        print('password', password)
        print('password com', passwordConfirm)
        if firstName and lastName and email and password and passwordConfirm:
            print("All info inserted!")
            return render_template("signin.html")
        else:
            print('Input missing!') 


    return render_template("register.html")
    


if __name__=='__main__':
    app.debug=True
    app.run()