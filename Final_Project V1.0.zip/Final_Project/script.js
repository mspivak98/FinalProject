function checkpassword() {
  var errormessage, password,Fname;
 errormessage = document.getElementById("error");
 //errormessage.innerHTML = "";
 password = document.getElementById("password").value;
 password2 = document.getElementById("password2").value;
 Fname  = document.getElementById("Firstname").value;
 Lname  = document.getElementById("Lastname").value;
  var errortoThrow = "";



try {

if(Fname == "")  {
         	errortoThrow += "<br />Your First name is empty";
            }
if(Lname == "")  {
         	errortoThrow += "<br />Your Last name is empty";
            }

if(password == "")  {  //condition 1 if password field is empty
          	errortoThrow += "<br /> Your password is empty";
            }
if(password.length<6) {//condition 2 if password field character length less than 6
              	errortoThrow += "<br />  Your password is is too short.";
            }

if(/[A-Z]/g.test(password) == false){// conditon 3 if password field input character with no upper case
             	errortoThrow +=   "<br /> Your password  should have atleast one capital letter.";
            }
if(password != password2){// condition 4 if password does not match the second input
          	errortoThrow +=   "<br /> Your password  does not match.";
            }
if(/\d/g.test(password) == false){ // condition 5 if password does not have digt number
	     	errortoThrow += "<br />   Your password should have atleast one digit.";

	}
    throw errortoThrow;
}


catch(err) {
//change inner HTML message to the value we have thrown. In this example err is a string not a object becuase we specify the string. IF you didnt specify your error message on the string, the err will stay as default object.

         errormessage.innerHTML =  err;

   // errormessage.innerHTML = "Your input password  " + err;
  }
}
